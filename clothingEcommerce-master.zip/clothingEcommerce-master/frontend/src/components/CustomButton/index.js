function CustomButton({children,...otherProps}) {
    return ( <>
    <button >
    
    </button>
    </>);
}

export default CustomButton;