import CardMenuBottom from "../components/CardMenuBottom";
import CardMenuTop from "../components/CardMenuTop";
function CardMenu() {
    return ( <>
    <CardMenuTop/>
    <CardMenuBottom/>
    </> );
}

export default CardMenu;